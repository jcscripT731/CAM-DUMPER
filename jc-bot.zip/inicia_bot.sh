#!/bin/bash
dir=$(pwd)
while true; do php $dir/bot.php; done;